# BGMI Tournament Bot - Deployment Guide

## Overview
This guide will help you deploy your BGMI Tournament Bot on your own server.

## Prerequisites
- Python 3.11 or higher
- MongoDB database (local or cloud)
- Server with internet access
- Basic command line knowledge

## Files Included
- `main.py` - Main bot application
- `handlers.py` - Bot command handlers
- `database.py` - Database operations
- `utils.py` - Utility functions
- `config.py` - Configuration settings
- `requirements.txt` - Python dependencies
- `run.sh` - Startup script
- `systemd/` - System service files
- `nginx/` - Web server configuration (optional)

## Installation Steps

### 1. Server Setup
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Python and pip
sudo apt install python3 python3-pip python3-venv -y

# Install MongoDB (optional - if using local database)
sudo apt install mongodb -y
sudo systemctl start mongodb
sudo systemctl enable mongodb
```

### 2. Application Setup
```bash
# Create application directory
mkdir /opt/bgmi-tournament-bot
cd /opt/bgmi-tournament-bot

# Extract your bot files here
# Upload all Python files to this directory

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Configuration
Edit `config.py` and update the following:
- `BOT_TOKEN` - Your Telegram bot token
- `ADMIN_ID` - Your admin user ID
- `MONGODB_URI` - Your MongoDB connection string
- `CHANNEL_ID` - Your channel ID
- `UPI_ID` - Your UPI ID for payments

### 4. Database Setup
If using MongoDB Atlas (recommended):
1. Create account at mongodb.com
2. Create new cluster
3. Get connection string
4. Update MONGODB_URI in config.py

### 5. Running the Bot

#### Option A: Direct Run
```bash
source venv/bin/activate
python main.py
```

#### Option B: Using Screen (Recommended)
```bash
# Install screen
sudo apt install screen -y

# Start bot in screen session
screen -S bgmi-bot
source venv/bin/activate
python main.py

# Detach: Ctrl+A, then D
# Reattach: screen -r bgmi-bot
```

#### Option C: System Service (Production)
```bash
# Copy service file
sudo cp systemd/bgmi-bot.service /etc/systemd/system/

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable bgmi-bot
sudo systemctl start bgmi-bot

# Check status
sudo systemctl status bgmi-bot
```

### 6. Monitoring and Logs
```bash
# View logs (if using systemd)
sudo journalctl -u bgmi-bot -f

# Check if bot is running
ps aux | grep python
```

## Security Considerations

### 1. Environment Variables
Never hardcode sensitive data. Use environment variables:
```bash
export BOT_TOKEN="your_bot_token_here"
export MONGODB_URI="your_mongodb_uri_here"
```

### 2. Firewall Setup
```bash
# Allow SSH
sudo ufw allow ssh

# Allow HTTP/HTTPS (if using webhook)
sudo ufw allow 80
sudo ufw allow 443

# Enable firewall
sudo ufw enable
```

### 3. SSL Certificate (Optional)
If using webhooks instead of polling:
```bash
# Install certbot
sudo apt install certbot -y

# Get certificate
sudo certbot certonly --standalone -d yourdomain.com
```

## Troubleshooting

### Common Issues:
1. **Bot not responding**: Check token and permissions
2. **Database connection failed**: Verify MongoDB URI
3. **Permission denied**: Check file permissions
4. **Port already in use**: Kill existing processes

### Useful Commands:
```bash
# Check bot process
pgrep -f "python main.py"

# Kill bot process
pkill -f "python main.py"

# Check logs
tail -f /var/log/bgmi-bot.log
```

## Performance Optimization

### 1. Resource Monitoring
```bash
# Install htop
sudo apt install htop -y

# Monitor resources
htop
```

### 2. Database Optimization
- Use MongoDB indexes
- Monitor query performance
- Regular backups

### 3. Bot Optimization
- Implement rate limiting
- Use connection pooling
- Monitor memory usage

## Backup Strategy
```bash
# Create backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mongodump --uri="your_mongodb_uri" --out /backup/bgmi_$DATE
tar -czf /backup/bgmi_$DATE.tar.gz /backup/bgmi_$DATE
```

## Support
- Check logs first
- Verify configuration
- Test MongoDB connection
- Ensure bot token is valid

## Updates
To update the bot:
1. Stop the service
2. Replace Python files
3. Update dependencies if needed
4. Restart the service

```bash
sudo systemctl stop bgmi-bot
# Replace files
pip install -r requirements.txt
sudo systemctl start bgmi-bot
```