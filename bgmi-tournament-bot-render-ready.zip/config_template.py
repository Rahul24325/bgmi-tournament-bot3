# Configuration Template for BGMI Tournament Bot
# Copy this file to config.py and update with your credentials

import os

# Bot Configuration
BOT_TOKEN = os.getenv('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
ADMIN_ID = int(os.getenv('ADMIN_ID', 'YOUR_ADMIN_ID_HERE'))

# Database Configuration
MONGODB_URI = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/bgmi_tournament')

# Channel Configuration
CHANNEL_ID = os.getenv('CHANNEL_ID', 'YOUR_CHANNEL_ID_HERE')
CHANNEL_USERNAME = os.getenv('CHANNEL_USERNAME', 'YOUR_CHANNEL_USERNAME_HERE')

# Payment Configuration
UPI_ID = os.getenv('UPI_ID', 'YOUR_UPI_ID_HERE')

# Bot Messages
START_MESSAGE = """🎮 **Welcome to VIP BGMI Tournament Manager!**

🔥 **Features:**
⚡ Tournament Registration
💰 Payment Processing
🏆 Team Selection
👥 Player Management
🎯 Admin Controls

🎪 **Join our channel first to participate in tournaments!**"""

CHANNEL_JOIN_MESSAGE = """🎮 **Join Our Channel First!**

⚡ **To participate in tournaments, you must join our official channel:**

👥 **Channel:** @{channel_username}

🎯 **After joining, click 'Check Membership' to continue!**"""

RULES_MESSAGE = """📋 **TOURNAMENT RULES**

🎮 **General Rules:**
1️⃣ Must join our official channel
2️⃣ Payment required for registration
3️⃣ No refunds after registration
4️⃣ Follow fair play guidelines
5️⃣ Admin decisions are final

⚡ **Tournament Rules:**
🔥 Classic/Sanhok map only
💀 No hacking or cheating
🎯 Squad format (4 players)
🏆 Winners decided by eliminations + rank
⚔️ Admin will provide room details

⚠️ **Violations result in disqualification!**"""

DISCLAIMER_MESSAGE = """⚠️ **DISCLAIMER**

🎮 **Important Information:**
• This is a skill-based game tournament
• Entry fees are non-refundable
• Prizes will be distributed as announced
• We are not responsible for technical issues
• All decisions are final

🔥 **By participating, you agree to these terms!**"""

# Webhook Configuration (Optional)
WEBHOOK_URL = os.getenv('WEBHOOK_URL', '')
WEBHOOK_PORT = int(os.getenv('WEBHOOK_PORT', '8000'))

# Logging Configuration
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FILE = os.getenv('LOG_FILE', 'bgmi_bot.log')

# Rate Limiting
MAX_REQUESTS_PER_MINUTE = int(os.getenv('MAX_REQUESTS_PER_MINUTE', '30'))

# Team Options
TEAM_OPTIONS = [
    {"callback": "team_fire", "name": "🔥 Fire Squad"},
    {"callback": "team_thunder", "name": "⚡ Thunder Team"},
    {"callback": "team_star", "name": "🌟 Star Warriors"},
    {"callback": "team_death", "name": "💀 Death Squad"},
    {"callback": "team_elite", "name": "🎯 Elite Squad"},
    {"callback": "team_champion", "name": "🏆 Champion Team"},
    {"callback": "team_rocket", "name": "🚀 Rocket Squad"},
    {"callback": "team_battle", "name": "⚔️ Battle Team"},
    {"callback": "team_random", "name": "🎮 Random Team"}
]