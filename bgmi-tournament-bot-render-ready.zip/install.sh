#!/bin/bash

# BGMI Tournament Bot - Automated Installation Script
# This script sets up the bot on Ubuntu/Debian systems

set -e

echo "🎮 BGMI Tournament Bot - Installation Script"
echo "=============================================="

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "❌ This script must be run as root (use sudo)"
   exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install Python and dependencies
echo "🐍 Installing Python and dependencies..."
apt install -y python3 python3-pip python3-venv git curl wget

# Install MongoDB (optional)
read -p "📊 Install MongoDB locally? (y/n): " install_mongo
if [[ $install_mongo == "y" ]]; then
    apt install -y mongodb
    systemctl start mongodb
    systemctl enable mongodb
    echo "✅ MongoDB installed and started"
fi

# Create application directory
APP_DIR="/opt/bgmi-tournament-bot"
echo "📁 Creating application directory: $APP_DIR"
mkdir -p $APP_DIR

# Copy files
echo "📋 Copying application files..."
cp -r * $APP_DIR/
cd $APP_DIR

# Create virtual environment
echo "🔧 Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
echo "📦 Installing Python dependencies..."
pip install -r dependencies.txt

# Make scripts executable
chmod +x run.sh
chmod +x backup.sh

# Install systemd service
echo "⚙️  Installing systemd service..."
cp systemd/bgmi-bot.service /etc/systemd/system/
systemctl daemon-reload

# Create log directory
mkdir -p /var/log/bgmi-bot
chown -R $USER:$USER /var/log/bgmi-bot

# Set permissions
chown -R $USER:$USER $APP_DIR

echo ""
echo "✅ Installation completed successfully!"
echo ""
echo "📝 Next steps:"
echo "1. Configure your bot: cd $APP_DIR && cp config_template.py config.py"
echo "2. Edit config.py with your credentials"
echo "3. Start the bot: systemctl start bgmi-bot"
echo "4. Enable auto-start: systemctl enable bgmi-bot"
echo ""
echo "📊 Check status: systemctl status bgmi-bot"
echo "📋 View logs: journalctl -u bgmi-bot -f"
echo ""
echo "🎉 Happy tournament hosting!"
