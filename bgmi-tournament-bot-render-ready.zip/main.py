import logging
import asyncio
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ConversationHandler
from handlers import BotHandlers, TOURNAMENT_NAME, TOURNAMENT_DATE, TOURNAMENT_TIME, TOURNAMENT_FEE, TOURNAMENT_PRIZE, TOURNAMENT_MAP, TOURNAMENT_UPI, WINNER_1, WINNER_2, WINNER_3, TEAM_SELECTION
from config import BOT_TOKEN

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def main():
    """Main function to run the bot"""
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Create handlers instance
    handlers = BotHandlers()
    
    # Add command handlers
    application.add_handler(CommandHandler("start", handlers.start_command))
    application.add_handler(CommandHandler("paid", handlers.paid_command))
    application.add_handler(CommandHandler("confirm", handlers.confirm_command))
    application.add_handler(CommandHandler("sendroom", handlers.sendroom_command))
    application.add_handler(CommandHandler("listplayers", handlers.listplayers_command))
    
    # Add conversation handler for tournament creation
    tournament_conv_handler = ConversationHandler(
        entry_points=[CommandHandler("createtournament", handlers.create_tournament_command)],
        states={
            TOURNAMENT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.tournament_name_handler)],
            TOURNAMENT_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.tournament_date_handler)],
            TOURNAMENT_TIME: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.tournament_time_handler)],
            TOURNAMENT_FEE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.tournament_fee_handler)],
            TOURNAMENT_PRIZE: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.tournament_prize_handler)],
            TOURNAMENT_MAP: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.tournament_map_handler)],
            TOURNAMENT_UPI: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.tournament_upi_handler)],
        },
        fallbacks=[CommandHandler("cancel", handlers.cancel_command)]
    )
    
    # Add conversation handler for winners declaration
    winners_conv_handler = ConversationHandler(
        entry_points=[CommandHandler("declarewinners", handlers.declarewinners_command)],
        states={
            WINNER_1: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.winner_1_handler)],
            WINNER_2: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.winner_2_handler)],
            WINNER_3: [MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.winner_3_handler)],
        },
        fallbacks=[CommandHandler("cancel", handlers.cancel_command)]
    )
    
    application.add_handler(tournament_conv_handler)
    application.add_handler(winners_conv_handler)
    
    # Add callback query handler
    application.add_handler(CallbackQueryHandler(handlers.callback_query_handler))
    
    # Add message handler for room details
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.handle_room_details))
    
    # Error handler
    async def error_handler(update, context):
        logger.error(f"Update {update} caused error {context.error}")
    
    application.add_error_handler(error_handler)
    
    # Start the bot
    logger.info("Starting VIP BGMI Tournament Manager Bot...")
    application.run_polling(allowed_updates=["message", "callback_query"])

if __name__ == "__main__":
    main()
