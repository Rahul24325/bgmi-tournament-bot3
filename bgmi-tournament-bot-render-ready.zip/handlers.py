from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import db
from utils import (
    is_admin, check_channel_membership, create_join_channel_keyboard,
    create_tournament_keyboard, create_team_selection_keyboard, format_tournament_post, format_room_details,
    format_winners_announcement, send_typing_action, format_players_list,
    is_valid_username, extract_username
)
from config import *
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# Conversation states
(TOURNAMENT_NAME, TOURNAMENT_DATE, TOURNAMENT_TIME, TOURNAMENT_FEE, 
 TOURNAMENT_PRIZE, TOURNAMENT_MAP, TOURNAMENT_UPI, ROOM_ID, ROOM_PASSWORD,
 WINNER_1, WINNER_2, WINNER_3, TEAM_SELECTION) = range(13)

class BotHandlers:
    def __init__(self):
        self.user_states = {}

    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user = update.effective_user
        chat_id = update.effective_chat.id
        
        # Add user to database
        db.add_user(user.id, user.username, user.first_name, user.last_name)
        
        # Check if user is in channel
        if await check_channel_membership(context, user.id):
            db.update_user_channel_status(user.id, True)
            await self.send_main_menu(update, context)
        else:
            await send_typing_action(context, chat_id)
            await context.bot.send_message(
                chat_id=chat_id,
                text=WELCOME_MESSAGE,
                reply_markup=create_join_channel_keyboard(),
                parse_mode='Markdown'
            )

    async def send_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Send main menu after channel verification"""
        user = update.effective_user
        chat_id = update.effective_chat.id
        
        welcome_text = f"""
🎮 **Welcome back, {user.first_name}!** 🎮

🔥 **You're all set to participate in tournaments!** 🔥

🏆 **Available Commands:**
• Check active tournaments
• View your tournament history
• Get support

⚡ **Ready to dominate the battlegrounds?** ⚡
"""
        
        keyboard = [
            [InlineKeyboardButton("🎯 Active Tournaments", callback_data="active_tournaments")],
            [InlineKeyboardButton("📊 My History", callback_data="my_history")],
            [InlineKeyboardButton("💬 Support", callback_data="support")]
        ]
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=welcome_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )

    async def callback_query_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle callback queries from inline keyboards"""
        query = update.callback_query
        await query.answer()
        
        if query.data == "check_membership":
            await self.check_membership_callback(update, context)
        elif query.data == "join_tournament":
            await self.join_tournament_callback(update, context)
        elif query.data == "show_rules":
            await self.show_rules_callback(update, context)
        elif query.data == "show_disclaimer":
            await self.show_disclaimer_callback(update, context)
        elif query.data == "active_tournaments":
            await self.show_active_tournaments(update, context)
        elif query.data.startswith("team_"):
            await self.team_selection_callback(update, context)

    async def check_membership_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Check if user joined the channel"""
        user = update.effective_user
        chat_id = update.effective_chat.id
        query = update.callback_query
        
        if await check_channel_membership(context, user.id):
            db.update_user_channel_status(user.id, True)
            await query.edit_message_text(
                text="✅ **Channel membership verified!**\n\n🎮 **You can now participate in tournaments!**",
                parse_mode='Markdown'
            )
            await self.send_main_menu(update, context)
        else:
            await query.edit_message_text(
                text="❌ **Please join the channel first!**\n\n👆 **Click the 'Join Channel' button above and try again.**",
                reply_markup=create_join_channel_keyboard(),
                parse_mode='Markdown'
            )

    async def join_tournament_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament join request"""
        user = update.effective_user
        chat_id = update.effective_chat.id
        query = update.callback_query
        
        # Check channel membership
        if not await check_channel_membership(context, user.id):
            await query.answer("❌ Please join the channel first!", show_alert=True)
            return
        
        # Get active tournament
        tournament = db.get_active_tournament()
        if not tournament:
            await query.answer("❌ No active tournaments!", show_alert=True)
            return
        
        # Check if already registered
        players = db.get_tournament_players(tournament['_id'])
        if any(p['user_id'] == user.id for p in players):
            await query.answer("ℹ️ You're already registered!", show_alert=True)
            return
        
        # Store tournament info for team selection
        context.user_data['tournament_id'] = tournament['_id']
        context.user_data['tournament_fee'] = tournament['entry_fee']
        context.user_data['tournament_upi'] = tournament['upi_id']
        
        # Show team selection interface
        await query.edit_message_text(
            text=f"""🎯 **Choose Your Team**

🏆 **Tournament:** {tournament['name']}
💰 **Entry Fee:** ₹{tournament['entry_fee']}

🎮 **Select your team from the options below:**""",
            reply_markup=create_team_selection_keyboard(),
            parse_mode='Markdown'
        )

    async def team_selection_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle team selection"""
        user = update.effective_user
        query = update.callback_query
        
        # Team mapping
        team_mapping = {
            "team_fire": "🔥 Fire Squad",
            "team_thunder": "⚡ Thunder Team", 
            "team_star": "🌟 Star Warriors",
            "team_death": "💀 Death Squad",
            "team_elite": "🎯 Elite Squad",
            "team_champion": "🏆 Champion Team",
            "team_rocket": "🚀 Rocket Squad",
            "team_battle": "⚔️ Battle Team",
            "team_random": "🎮 Random Team"
        }
        
        selected_team = team_mapping.get(query.data, "🎮 Random Team")
        
        # Get tournament data from context
        tournament_id = context.user_data.get('tournament_id')
        tournament_fee = context.user_data.get('tournament_fee')
        tournament_upi = context.user_data.get('tournament_upi')
        
        if not tournament_id:
            await query.answer("❌ Session expired. Please try again!", show_alert=True)
            return
        
        # Add player to tournament with team selection
        db.add_player_to_tournament(tournament_id, user.id, user.username or f"User{user.id}", selected_team)
        
        # Send payment instructions
        payment_text = f"""💳 **PAYMENT INSTRUCTIONS**

🎯 **Selected Team:** {selected_team}
💰 **Amount:** ₹{tournament_fee}
📱 **UPI ID:** {tournament_upi}

**Steps to complete registration:**
1️⃣ Pay ₹{tournament_fee} to UPI: {tournament_upi}
2️⃣ Take a screenshot of the payment
3️⃣ Send the screenshot to admin
4️⃣ Click /paid after sending the screenshot

⚠️ **Important:** Only after admin confirmation, you'll be registered for the tournament!"""
        
        await context.bot.send_message(
            chat_id=user.id,
            text=payment_text,
            parse_mode='Markdown'
        )
        
        await query.edit_message_text(
            text=f"""✅ **Team Selected Successfully!**

🎯 **Your Team:** {selected_team}
💰 **Entry Fee:** ₹{tournament_fee}

📱 **Payment instructions have been sent to your DM.**

⚡ **Complete your payment and click /paid to confirm!**""",
            parse_mode='Markdown'
        )

    async def show_rules_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show tournament rules"""
        await update.callback_query.edit_message_text(
            text=RULES_MESSAGE,
            parse_mode='Markdown'
        )

    async def show_disclaimer_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show disclaimer"""
        await update.callback_query.edit_message_text(
            text=DISCLAIMER_MESSAGE,
            parse_mode='Markdown'
        )

    async def show_active_tournaments(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show active tournaments"""
        tournament = db.get_active_tournament()
        if tournament:
            text = format_tournament_post(tournament)
            await update.callback_query.edit_message_text(
                text=text,
                reply_markup=create_tournament_keyboard(),
                parse_mode='Markdown'
            )
        else:
            await update.callback_query.edit_message_text(
                text="📅 **No active tournaments at the moment.**\n\nStay tuned for upcoming tournaments!",
                parse_mode='Markdown'
            )

    async def create_tournament_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start tournament creation process (Admin only)"""
        user = update.effective_user
        
        if not await is_admin(user.id):
            await update.message.reply_text("❌ **This command is for admins only!**", parse_mode='Markdown')
            return ConversationHandler.END
        
        await update.message.reply_text(
            "🎮 **Creating new tournament...**\n\n📝 **Please enter the tournament name:**",
            parse_mode='Markdown'
        )
        return TOURNAMENT_NAME

    async def tournament_name_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament name input"""
        context.user_data['tournament_name'] = update.message.text
        await update.message.reply_text(
            "📅 **Please enter the tournament date (DD/MM/YYYY):**"
        )
        return TOURNAMENT_DATE

    async def tournament_date_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament date input"""
        context.user_data['tournament_date'] = update.message.text
        await update.message.reply_text(
            "🕘 **Please enter the tournament time (HH:MM AM/PM):**"
        )
        return TOURNAMENT_TIME

    async def tournament_time_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament time input"""
        context.user_data['tournament_time'] = update.message.text
        await update.message.reply_text(
            "💰 **Please enter the entry fee amount (₹):**"
        )
        return TOURNAMENT_FEE

    async def tournament_fee_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament fee input"""
        try:
            context.user_data['tournament_fee'] = int(update.message.text)
            await update.message.reply_text(
                "🎁 **Please enter the prize pool amount (₹):**"
            )
            return TOURNAMENT_PRIZE
        except ValueError:
            await update.message.reply_text(
                "❌ **Please enter a valid number for the entry fee:**"
            )
            return TOURNAMENT_FEE

    async def tournament_prize_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament prize input"""
        try:
            context.user_data['tournament_prize'] = int(update.message.text)
            await update.message.reply_text(
                "📍 **Please enter the map name:**"
            )
            return TOURNAMENT_MAP
        except ValueError:
            await update.message.reply_text(
                "❌ **Please enter a valid number for the prize pool:**"
            )
            return TOURNAMENT_PRIZE

    async def tournament_map_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament map input"""
        context.user_data['tournament_map'] = update.message.text
        await update.message.reply_text(
            f"📱 **Please enter the UPI ID for payments (default: {UPI_ID}):**"
        )
        return TOURNAMENT_UPI

    async def tournament_upi_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle tournament UPI input and create tournament"""
        upi_id = update.message.text.strip() or UPI_ID
        
        tournament_data = {
            'name': context.user_data['tournament_name'],
            'date': context.user_data['tournament_date'],
            'time': context.user_data['tournament_time'],
            'entry_fee': context.user_data['tournament_fee'],
            'prize_pool': context.user_data['tournament_prize'],
            'map': context.user_data['tournament_map'],
            'upi_id': upi_id
        }
        
        tournament_id = db.create_tournament(tournament_data)
        
        if tournament_id:
            # Send tournament post to group
            post_text = format_tournament_post(tournament_data)
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=post_text,
                reply_markup=create_tournament_keyboard(),
                parse_mode='Markdown'
            )
            
            await update.message.reply_text(
                "✅ **Tournament created successfully!**\n\n🎯 **Tournament post sent to the group!**",
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                "❌ **Failed to create tournament. Please try again.**",
                parse_mode='Markdown'
            )
        
        return ConversationHandler.END

    async def paid_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /paid command"""
        user = update.effective_user
        
        # Get active tournament
        tournament = db.get_active_tournament()
        if not tournament:
            await update.message.reply_text("❌ **No active tournaments!**", parse_mode='Markdown')
            return
        
        # Check if user is registered
        players = db.get_tournament_players(tournament['_id'])
        if not any(p['user_id'] == user.id for p in players):
            await update.message.reply_text("❌ **You're not registered for this tournament!**", parse_mode='Markdown')
            return
        
        # Log payment attempt
        db.log_payment(user.id, tournament['_id'], tournament['entry_fee'], tournament['upi_id'])
        
        # Notify admin
        admin_text = f"""
🧾 **JOIN REQUEST**

👤 **User:** {user.username or f'User{user.id}'}
💰 **Amount:** ₹{tournament['entry_fee']}
🏆 **Tournament:** {tournament['name']}

⏳ **Awaiting confirmation...**
"""
        
        await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=admin_text,
            parse_mode='Markdown'
        )
        
        await update.message.reply_text(
            "✅ **Payment notification sent to admin!**\n\n⏳ **Please wait for confirmation...**",
            parse_mode='Markdown'
        )

    async def confirm_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /confirm command (Admin only)"""
        user = update.effective_user
        
        if not await is_admin(user.id):
            await update.message.reply_text("❌ **This command is for admins only!**", parse_mode='Markdown')
            return
        
        # Extract username from command
        username = extract_username(update.message.text)
        if not username:
            await update.message.reply_text(
                "❌ **Please provide a username!**\n\nUsage: `/confirm @username`",
                parse_mode='Markdown'
            )
            return
        
        # Get active tournament
        tournament = db.get_active_tournament()
        if not tournament:
            await update.message.reply_text("❌ **No active tournaments!**", parse_mode='Markdown')
            return
        
        # Find user by username
        players = db.get_tournament_players(tournament['_id'])
        target_player = None
        for player in players:
            if player['username'] == username:
                target_player = player
                break
        
        if not target_player:
            await update.message.reply_text(
                f"❌ **User {username} not found in tournament!**",
                parse_mode='Markdown'
            )
            return
        
        # Confirm player
        db.confirm_player_payment(tournament['_id'], target_player['user_id'])
        
        # Notify user
        confirmation_text = f"""
✅ **You're confirmed for the tournament!**

🏆 **Tournament:** {tournament['name']}
📅 **Date:** {tournament['date']}
🕘 **Time:** {tournament['time']}

🎮 **Room details will be shared before match time.**
"""
        
        await context.bot.send_message(
            chat_id=target_player['user_id'],
            text=confirmation_text,
            parse_mode='Markdown'
        )
        
        await update.message.reply_text(
            f"✅ **{username} confirmed successfully!**",
            parse_mode='Markdown'
        )

    async def sendroom_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /sendroom command (Admin only)"""
        user = update.effective_user
        
        if not await is_admin(user.id):
            await update.message.reply_text("❌ **This command is for admins only!**", parse_mode='Markdown')
            return
        
        await update.message.reply_text(
            "🎮 **Sending room details...**\n\n🆔 **Please enter the Room ID:**"
        )
        self.user_states[user.id] = 'awaiting_room_id'

    async def handle_room_details(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle room details input"""
        user = update.effective_user
        
        if user.id not in self.user_states:
            return
        
        state = self.user_states[user.id]
        
        if state == 'awaiting_room_id':
            context.user_data['room_id'] = update.message.text
            await update.message.reply_text("🔑 **Please enter the Room Password:**")
            self.user_states[user.id] = 'awaiting_room_password'
        
        elif state == 'awaiting_room_password':
            context.user_data['room_password'] = update.message.text
            
            # Get active tournament
            tournament = db.get_active_tournament()
            if not tournament:
                await update.message.reply_text("❌ **No active tournaments!**", parse_mode='Markdown')
                return
            
            # Get confirmed players
            confirmed_players = db.get_confirmed_players(tournament['_id'])
            
            if not confirmed_players:
                await update.message.reply_text("❌ **No confirmed players!**", parse_mode='Markdown')
                return
            
            # Update tournament with room details
            tournament['room_id'] = context.user_data['room_id']
            tournament['room_password'] = context.user_data['room_password']
            
            # Send room details to all confirmed players
            room_text = format_room_details(tournament)
            
            sent_count = 0
            for player in confirmed_players:
                try:
                    await context.bot.send_message(
                        chat_id=player['user_id'],
                        text=room_text,
                        parse_mode='Markdown'
                    )
                    sent_count += 1
                except Exception as e:
                    logger.error(f"Failed to send room details to {player['user_id']}: {e}")
            
            # Mark room as sent
            db.update_tournament_room_sent(tournament['_id'])
            
            await update.message.reply_text(
                f"✅ **Room details sent to {sent_count} confirmed players!**",
                parse_mode='Markdown'
            )
            
            del self.user_states[user.id]

    async def listplayers_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /listplayers command (Admin only)"""
        user = update.effective_user
        
        if not await is_admin(user.id):
            await update.message.reply_text("❌ **This command is for admins only!**", parse_mode='Markdown')
            return
        
        # Get active tournament
        tournament = db.get_active_tournament()
        if not tournament:
            await update.message.reply_text("❌ **No active tournaments!**", parse_mode='Markdown')
            return
        
        # Get tournament players
        players = db.get_tournament_players(tournament['_id'])
        players_text = format_players_list(players)
        
        await update.message.reply_text(
            f"🏆 **{tournament['name']}**\n\n{players_text}",
            parse_mode='Markdown'
        )

    async def declarewinners_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /declarewinners command (Admin only)"""
        user = update.effective_user
        
        if not await is_admin(user.id):
            await update.message.reply_text("❌ **This command is for admins only!**", parse_mode='Markdown')
            return
        
        await update.message.reply_text(
            "🏆 **Declaring winners...**\n\n🥇 **Please enter 1st place details:**\n\nFormat: `@username points prize`\nExample: `@player1 25 500`",
            parse_mode='Markdown'
        )
        return WINNER_1

    async def winner_1_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle first place winner input"""
        try:
            parts = update.message.text.split()
            context.user_data['winner_1'] = {
                'username': parts[0],
                'points': int(parts[1]),
                'prize': int(parts[2])
            }
            await update.message.reply_text(
                "🥈 **Please enter 2nd place details:**\n\nFormat: `@username points prize`"
            )
            return WINNER_2
        except (IndexError, ValueError):
            await update.message.reply_text(
                "❌ **Invalid format!**\n\nFormat: `@username points prize`"
            )
            return WINNER_1

    async def winner_2_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle second place winner input"""
        try:
            parts = update.message.text.split()
            context.user_data['winner_2'] = {
                'username': parts[0],
                'points': int(parts[1]),
                'prize': int(parts[2])
            }
            await update.message.reply_text(
                "🥉 **Please enter 3rd place details:**\n\nFormat: `@username points prize`"
            )
            return WINNER_3
        except (IndexError, ValueError):
            await update.message.reply_text(
                "❌ **Invalid format!**\n\nFormat: `@username points prize`"
            )
            return WINNER_2

    async def winner_3_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle third place winner input and declare winners"""
        try:
            parts = update.message.text.split()
            context.user_data['winner_3'] = {
                'username': parts[0],
                'points': int(parts[1]),
                'prize': int(parts[2])
            }
            
            # Get active tournament
            tournament = db.get_active_tournament()
            if not tournament:
                await update.message.reply_text("❌ **No active tournaments!**", parse_mode='Markdown')
                return ConversationHandler.END
            
            # Prepare winners data
            winners = [
                context.user_data['winner_1'],
                context.user_data['winner_2'],
                context.user_data['winner_3']
            ]
            
            # Declare winners in database
            db.declare_winners(tournament['_id'], winners)
            
            # Send winners announcement
            winners_text = format_winners_announcement(winners)
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=winners_text,
                parse_mode='Markdown'
            )
            
            await update.message.reply_text(
                "✅ **Winners declared successfully!**",
                parse_mode='Markdown'
            )
            
            return ConversationHandler.END
            
        except (IndexError, ValueError):
            await update.message.reply_text(
                "❌ **Invalid format!**\n\nFormat: `@username points prize`"
            )
            return WINNER_3

    async def cancel_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Cancel current conversation"""
        await update.message.reply_text(
            "❌ **Operation cancelled.**",
            parse_mode='Markdown'
        )
        return ConversationHandler.END


