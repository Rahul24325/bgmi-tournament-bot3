from pymongo import MongoClient
from datetime import datetime
import logging
from config import MONGODB_URI, DATABASE_NAME, USERS_COLLECTION, TOURNAMENTS_COLLECTION, PAYMENTS_COLLECTION

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Database:
    def __init__(self):
        try:
            self.client = MongoClient(MONGODB_URI)
            self.db = self.client[DATABASE_NAME]
            self.users = self.db[USERS_COLLECTION]
            self.tournaments = self.db[TOURNAMENTS_COLLECTION]
            self.payments = self.db[PAYMENTS_COLLECTION]
            logger.info("Database connected successfully")
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            raise

    def add_user(self, user_id, username, first_name, last_name=None):
        """Add or update user in database"""
        try:
            user_data = {
                "user_id": user_id,
                "username": username,
                "first_name": first_name,
                "last_name": last_name,
                "joined_at": datetime.now(),
                "channel_joined": False,
                "tournaments_joined": [],
                "is_active": True
            }
            
            self.users.update_one(
                {"user_id": user_id},
                {"$setOnInsert": user_data},
                upsert=True
            )
            return True
        except Exception as e:
            logger.error(f"Error adding user: {e}")
            return False

    def get_user(self, user_id):
        """Get user from database"""
        try:
            return self.users.find_one({"user_id": user_id})
        except Exception as e:
            logger.error(f"Error getting user: {e}")
            return None

    def update_user_channel_status(self, user_id, status):
        """Update user's channel join status"""
        try:
            self.users.update_one(
                {"user_id": user_id},
                {"$set": {"channel_joined": status}}
            )
            return True
        except Exception as e:
            logger.error(f"Error updating channel status: {e}")
            return False

    def create_tournament(self, tournament_data):
        """Create a new tournament"""
        try:
            tournament_data["created_at"] = datetime.now()
            tournament_data["players"] = []
            tournament_data["confirmed_players"] = []
            tournament_data["room_sent"] = False
            tournament_data["winners_declared"] = False
            
            result = self.tournaments.insert_one(tournament_data)
            return str(result.inserted_id)
        except Exception as e:
            logger.error(f"Error creating tournament: {e}")
            return None

    def get_active_tournament(self):
        """Get the most recent active tournament"""
        try:
            return self.tournaments.find_one(
                {"winners_declared": False},
                sort=[("created_at", -1)]
            )
        except Exception as e:
            logger.error(f"Error getting active tournament: {e}")
            return None

    def add_player_to_tournament(self, tournament_id, user_id, username, team_name=None):
        """Add player to tournament"""
        try:
            player_data = {
                "user_id": user_id, 
                "username": username, 
                "paid": False, 
                "confirmed": False,
                "team_name": team_name,
                "joined_at": datetime.now()
            }
            self.tournaments.update_one(
                {"_id": tournament_id},
                {"$addToSet": {"players": player_data}}
            )
            return True
        except Exception as e:
            logger.error(f"Error adding player to tournament: {e}")
            return False

    def update_player_team(self, tournament_id, user_id, team_name):
        """Update player's team selection"""
        try:
            self.tournaments.update_one(
                {"_id": tournament_id, "players.user_id": user_id},
                {"$set": {"players.$.team_name": team_name}}
            )
            return True
        except Exception as e:
            logger.error(f"Error updating player team: {e}")
            return False

    def confirm_player_payment(self, tournament_id, user_id):
        """Confirm player payment"""
        try:
            self.tournaments.update_one(
                {"_id": tournament_id, "players.user_id": user_id},
                {"$set": {"players.$.confirmed": True}}
            )
            return True
        except Exception as e:
            logger.error(f"Error confirming player: {e}")
            return False

    def get_tournament_players(self, tournament_id):
        """Get all players for a tournament"""
        try:
            tournament = self.tournaments.find_one({"_id": tournament_id})
            return tournament.get("players", []) if tournament else []
        except Exception as e:
            logger.error(f"Error getting tournament players: {e}")
            return []

    def get_confirmed_players(self, tournament_id):
        """Get confirmed players for a tournament"""
        try:
            tournament = self.tournaments.find_one({"_id": tournament_id})
            if tournament:
                return [p for p in tournament.get("players", []) if p.get("confirmed", False)]
            return []
        except Exception as e:
            logger.error(f"Error getting confirmed players: {e}")
            return []

    def update_tournament_room_sent(self, tournament_id):
        """Mark room details as sent"""
        try:
            self.tournaments.update_one(
                {"_id": tournament_id},
                {"$set": {"room_sent": True}}
            )
            return True
        except Exception as e:
            logger.error(f"Error updating room sent status: {e}")
            return False

    def declare_winners(self, tournament_id, winners_data):
        """Declare tournament winners"""
        try:
            self.tournaments.update_one(
                {"_id": tournament_id},
                {"$set": {"winners": winners_data, "winners_declared": True}}
            )
            return True
        except Exception as e:
            logger.error(f"Error declaring winners: {e}")
            return False

    def log_payment(self, user_id, tournament_id, amount, upi_id, status="pending"):
        """Log payment attempt"""
        try:
            payment_data = {
                "user_id": user_id,
                "tournament_id": tournament_id,
                "amount": amount,
                "upi_id": upi_id,
                "status": status,
                "timestamp": datetime.now()
            }
            self.payments.insert_one(payment_data)
            return True
        except Exception as e:
            logger.error(f"Error logging payment: {e}")
            return False

# Initialize database connection
db = Database()
