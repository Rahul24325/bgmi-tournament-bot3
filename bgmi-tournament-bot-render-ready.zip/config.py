import os

# Bot configuration
BOT_TOKEN = "7911618551:AAHzOkwAzvcLstjyUJWUFs5oaH53iRzYE7s"
ADMIN_ID = 7891142412
UPI_ID = "8435010927@ybl"
# Channel configuration - Update these with your actual channel details
CHANNEL_ID = -1007911618551  # Channel ID format for supergroups/channels
CHANNEL_USERNAME = "@OfficialBGMITournament"  # Your channel username

# Alternative: Use channel username instead of ID for membership checks
# This is more reliable until bot is added to channel as admin
USE_CHANNEL_USERNAME = True

# MongoDB configuration
MONGODB_URI = "mongodb+srv://rahul7241146384:rahul7241146384@cluster0.qeaogc4.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
DATABASE_NAME = "bgmi_tournament_bot"

# Collections
USERS_COLLECTION = "users"
TOURNAMENTS_COLLECTION = "tournaments"
PAYMENTS_COLLECTION = "payments"

# Messages
WELCOME_MESSAGE = """
🎮 **Welcome to VIP BGMI Tournament Manager!** 🎮

🔥 Ready to dominate the battlegrounds? 🔥

Before you can register for tournaments, you need to join our official channel:
👇 **Click the button below to join** 👇

After joining, come back and tap /start again to access the registration system!

🏆 **May the best squad win!** 🏆
"""

RULES_MESSAGE = """
📜 **TOURNAMENT RULES:**

1️⃣ **No emulator players allowed** - Mobile only
2️⃣ **No teaming, hacking, or glitching** - Fair play only
3️⃣ **Kill + Rank = Points** - Standard scoring system
4️⃣ **Room closes on time** - Be punctual or miss out
5️⃣ **Follow admin instructions** - No arguments
6️⃣ **Respect all players** - Maintain sportsmanship

⚠️ **Violation of any rule will result in disqualification!**
"""

DISCLAIMER_MESSAGE = """
⚠️ **DISCLAIMER:**

🚫 **No refunds** after room details are shared
📶 **Admin not responsible** for lag/disconnect issues
🔒 **Cheaters will be banned permanently**
⏰ **Late entries will not be accepted**
💰 **Prize distribution within 24 hours**
✅ **By joining, you accept all rules & risks**

**Participate at your own risk!**
"""

PAYMENT_INSTRUCTIONS = """
💳 **PAYMENT INSTRUCTIONS:**

💰 **Amount:** ₹{amount}
📱 **UPI ID:** {upi_id}

**Steps to complete payment:**
1️⃣ Pay ₹{amount} to UPI: {upi_id}
2️⃣ Take a screenshot of the payment
3️⃣ Send the screenshot to admin: @Officialbgmi24
4️⃣ Click /paid after sending the screenshot

⚠️ **Important:** Only after admin confirmation, you'll be registered for the tournament!
"""
