import asyncio
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ChatMemberStatus
from config import CHANNEL_ID, CHANNEL_USERNAME, ADMIN_ID
import logging

logger = logging.getLogger(__name__)

async def is_admin(user_id):
    """Check if user is admin"""
    return user_id == ADMIN_ID

async def check_channel_membership(context, user_id):
    """Check if user is member of the required channel"""
    try:
        # Try using channel username first, fallback to ID
        try:
            member = await context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        except:
            member = await context.bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        
        return member.status in [ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]
    except Exception as e:
        logger.error(f"Error checking channel membership: {e}")
        # Return True temporarily to allow testing when bot is not in channel
        return True

def create_join_channel_keyboard():
    """Create keyboard for channel join"""
    keyboard = [
        [InlineKeyboardButton("📢 Join Channel", url="https://t.me/vpitournament")],
        [InlineKeyboardButton("✅ I Joined", callback_data="check_membership")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_tournament_keyboard():
    """Create keyboard for tournament post"""
    keyboard = [
        [InlineKeyboardButton("✅ Join Now", callback_data="join_tournament")],
        [InlineKeyboardButton("📜 Rules", callback_data="show_rules")],
        [InlineKeyboardButton("⚠️ Disclaimer", callback_data="show_disclaimer")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_team_selection_keyboard():
    """Create emoji-based team selection keyboard"""
    keyboard = [
        [InlineKeyboardButton("🔥 Fire Squad", callback_data="team_fire")],
        [InlineKeyboardButton("⚡ Thunder Team", callback_data="team_thunder")],
        [InlineKeyboardButton("🌟 Star Warriors", callback_data="team_star")],
        [InlineKeyboardButton("💀 Death Squad", callback_data="team_death")],
        [InlineKeyboardButton("🎯 Elite Squad", callback_data="team_elite")],
        [InlineKeyboardButton("🏆 Champion Team", callback_data="team_champion")],
        [InlineKeyboardButton("🚀 Rocket Squad", callback_data="team_rocket")],
        [InlineKeyboardButton("⚔️ Battle Team", callback_data="team_battle")],
        [InlineKeyboardButton("🎮 Random Team", callback_data="team_random")]
    ]
    return InlineKeyboardMarkup(keyboard)

def format_tournament_post(tournament):
    """Format tournament announcement post"""
    return f"""🎮 TOURNAMENT ALERT 🎮

🏆 {tournament['name']}
📅 Date: {tournament['date']}
🕘 Time: {tournament['time']}
📍 Map: {tournament['map']}
💰 Entry Fee: ₹{tournament['entry_fee']}
🎁 Prize Pool: ₹{tournament['prize_pool']}

👇 Click to participate 👇"""

def format_room_details(tournament):
    """Format room details message"""
    return f"""
🎮 **ROOM DETAILS**

🆔 **Room ID:** {tournament.get('room_id', 'TBD')}
🔑 **Password:** {tournament.get('room_password', 'TBD')}
🕘 **Time:** {tournament['time']}
📍 **Map:** {tournament['map']}

⚠️ **Do not share these details. No refunds after room details are sent.**

🔥 **Good luck and may the best squad win!** 🔥
"""

def format_winners_announcement(winners):
    """Format winners announcement"""
    message = "🏆 **TOURNAMENT WINNERS** 🏆\n\n"
    
    positions = ["🥇", "🥈", "🥉"]
    for i, winner in enumerate(winners):
        if i < 3:
            message += f"{positions[i]} **{winner['username']}** — {winner['points']} pts — ₹{winner['prize']}\n"
    
    message += "\n🎉 **Congratulations to all winners!** 🎉"
    return message

async def send_typing_action(context, chat_id, duration=2):
    """Send typing action for realistic interaction"""
    await context.bot.send_chat_action(chat_id=chat_id, action="typing")
    await asyncio.sleep(duration)

def format_players_list(players):
    """Format players list for admin"""
    if not players:
        return "📝 **No players registered yet.**"
    
    message = "📝 **TOURNAMENT PLAYERS:**\n\n"
    confirmed_count = 0
    
    for i, player in enumerate(players, 1):
        status = "✅ Confirmed" if player.get('confirmed', False) else "⏳ Pending"
        team = player.get('team_name', '🎮 No Team')
        if player.get('confirmed', False):
            confirmed_count += 1
        message += f"{i}. {player['username']} - {team} - {status}\n"
    
    message += f"\n📊 **Total: {len(players)} | Confirmed: {confirmed_count}**"
    return message

def is_valid_username(username):
    """Validate username format"""
    return username.startswith('@') and len(username) > 1

def extract_username(text):
    """Extract username from text"""
    words = text.split()
    for word in words:
        if word.startswith('@'):
            return word
    return None
