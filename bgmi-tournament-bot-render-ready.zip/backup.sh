#!/bin/bash

# BGMI Tournament Bot - Database Backup Script
# This script creates backups of the MongoDB database

# Configuration
BACKUP_DIR="/backup/bgmi-tournament"
DATE=$(date +%Y%m%d_%H%M%S)
MONGODB_URI="mongodb://localhost:27017/bgmi_tournament"

# Create backup directory
mkdir -p $BACKUP_DIR

# Create database backup
echo "📊 Creating database backup..."
mongodump --uri="$MONGODB_URI" --out "$BACKUP_DIR/backup_$DATE"

# Compress backup
echo "🗜️  Compressing backup..."
cd $BACKUP_DIR
tar -czf "bgmi_backup_$DATE.tar.gz" "backup_$DATE"
rm -rf "backup_$DATE"

# Keep only last 7 backups
echo "🧹 Cleaning old backups..."
ls -t bgmi_backup_*.tar.gz | tail -n +8 | xargs rm -f

# Show backup info
echo "✅ Backup completed: bgmi_backup_$DATE.tar.gz"
echo "📁 Location: $BACKUP_DIR"
echo "📊 Size: $(du -h $BACKUP_DIR/bgmi_backup_$DATE.tar.gz | cut -f1)"

# Optional: Upload to cloud storage
# aws s3 cp "$BACKUP_DIR/bgmi_backup_$DATE.tar.gz" s3://your-bucket/backups/
