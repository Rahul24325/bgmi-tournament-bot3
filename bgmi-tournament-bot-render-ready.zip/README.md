# BGMI Tournament Bot - Deployment Package

## Quick Start

1. **Extract Files:**
   ```bash
   unzip bgmi-tournament-bot-*.zip
   cd bgmi-tournament-bot-deploy
   ```

2. **Run Installation Script:**
   ```bash
   chmod +x install.sh
   sudo ./install.sh
   ```

3. **Configure Bot:**
   ```bash
   cp config_template.py config.py
   nano config.py  # Update with your credentials
   ```

4. **Start Bot:**
   ```bash
   ./run.sh
   ```

## Files Included

- **Core Application:**
  - `main.py` - Bot entry point
  - `handlers.py` - Command handlers
  - `database.py` - Database operations
  - `utils.py` - Utility functions
  - `config.py` - Configuration (template)

- **Deployment:**
  - `install.sh` - Automated installation script
  - `run.sh` - Bot startup script
  - `backup.sh` - Database backup script
  - `systemd/` - System service files
  - `nginx/` - Web server configuration
  - `docker/` - Docker deployment files

- **Documentation:**
  - `deployment_guide.md` - Complete deployment guide
  - `README.md` - This file
  - `.env.example` - Environment variables template

## Support

For detailed instructions, see `deployment_guide.md`.

## Security Notes

- Update all credentials in `config.py`
- Use environment variables for sensitive data
- Enable firewall on your server
- Regular backups recommended

---
Generated on: 2025-07-14 08:34:07
