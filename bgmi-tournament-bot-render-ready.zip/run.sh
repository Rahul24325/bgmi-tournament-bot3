#!/bin/bash

# BGMI Tournament Bot Startup Script
# This script starts the bot with proper environment setup

# Set working directory
cd /opt/bgmi-tournament-bot

# Activate virtual environment
source venv/bin/activate

# Set environment variables (optional - can be set in system)
# export BOT_TOKEN="your_bot_token_here"
# export MONGODB_URI="your_mongodb_uri_here"
# export ADMIN_ID="your_admin_id_here"

# Start the bot
python main.py

# If the bot crashes, this will restart it
while [ $? -eq 1 ]; do
    echo "Bot crashed. Restarting in 5 seconds..."
    sleep 5
    python main.py
done